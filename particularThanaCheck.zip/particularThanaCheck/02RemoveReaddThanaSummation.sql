-- THana data delete from receiveddata
DELETE FROM bugs.schoolRowCountReceiveddata_intermediate 
WHERE
    school_code IN (SELECT 
        school_code
    FROM
        pesp_db_p23_live.school
    
    WHERE
        thana_id IN (100));

-- thana data re-added
INSERT INTO bugs.`schoolRowCountReceiveddata_intermediate`
SELECT 
    t1.school_code, t1.rowCount, t1.distinctMobCount, t2.RCount
FROM
    (SELECT 
        School_code,
            COUNT(*) rowCount,
            COUNT(DISTINCT MobileNo) distinctMobCount
    FROM
        pesp_db_p23_live.receiveddata
    GROUP BY School_code) t1
    INNER JOIN
    pesp_db_p23_live.school sc
    on t1.school_code = sc.school_code
        LEFT JOIN
    (SELECT 
        school_code, COUNT(DISTINCT MobileNo) RCount
    FROM
        pesp_db_p23_live.receiveddata
    WHERE
        Remark = 'R'
        group by school_code) t2
        on t1.school_code = t2.school_code
    where sc.thana_id in (100)
;





-- THana data delete from receiveddata
DELETE FROM bugs.schoolRowCountDsSheet_intermediate 
WHERE
    school_code IN (SELECT 
        school_code
    FROM
        pesp_db_p23_live.school
    
    WHERE
        thana_id IN (100));

ALTER TABLE bugs.schoolRowCountDsSheet_intermediate
DROP INDEX school_code ;

INSERT INTO bugs.schoolRowCountDsSheet_intermediate
Select school_code , count(*) rowCount, count(distinct mobile_no) distinctMobCount
from pesp_db_p23_live.disbursement_sheet_raw_data_report 
where 
school_code IN (SELECT 
        school_code
    FROM
        pesp_db_p23_live.school
    
    WHERE
        thana_id IN (100))
group by school_code;
ALTER TABLE bugs.schoolRowCountDsSheet_intermediate
ADD INDEX `school_code` (school_code ASC);