-- THana data delete from receiveddata
DELETE FROM bugs.rcvddataSchoolCodeMobNo 
WHERE
    school_code IN (SELECT 
        school_code
    FROM
        pesp_db_p23_live.school
    
    WHERE
        thana_id IN (100));

-- thana data re-insert
INSERT INTO bugs.rcvddataSchoolCodeMobNo
SELECT rd.school_code, rd.MobileNo from pesp_db_p23_live.receiveddata rd 
inner join pesp_db_p23_live.school sc
on rd.school_code = sc.school_code
where sc.thana_id in (100) 
group by rd.school_code, rd.MobileNo;




-- THana data delete from dsSheetData
DELETE FROM bugs.dssheetSchoolCodeMobNo 
WHERE
    school_code IN (SELECT 
        school_code
    FROM
        pesp_db_p23_live.school
    
    WHERE
        thana_id IN (100));

-- thana data re-insert
INSERT INTO bugs.dssheetSchoolCodeMobNo
SELECT ds.school_code, ds.mobile_no from pesp_db_p23_live.disbursement_sheet_raw_data_report ds 
inner join pesp_db_p23_live.school sc
on ds.school_code = sc.school_code
where sc.thana_id in (100) 
group by ds.school_code, ds.mobile_no
;
